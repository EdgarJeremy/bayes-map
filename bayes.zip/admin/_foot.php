

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
        <script src="../assets/js/dashboard.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAycCLQBE72kLbRXBqfCkRpMuwxFaeyIzE&callback=initMap" async defer></script>
    </body>
</html>
