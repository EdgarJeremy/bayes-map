<?php
session_start();

require_once 'helpers.php';
require_once 'db.php';